"""Slim demo package root."""
